import sys
import time
from pathlib import Path
from typing import Optional, Tuple

import cv2
import numpy
import numpy as np
import typer

from azure_kinect_video_player.playback_wrapper import AzureKinectPlaybackWrapper
from azure_kinect_video_player.image_scaler import map_uint16_to_uint8

app = typer.Typer()


@app.command()
def app_main(video_filename: Path = typer.Argument(..., help="The video filename"),
             realtime_wait: bool = typer.Option(True, help="Wait for the next frame to be displayed"),
             init_threshold: int = typer.Option(500, help="Initial threshold value")):

    # Get the video filename from the command line
    video_filename = Path(video_filename)

    # Create the playback wrapper
    playback_wrapper = AzureKinectPlaybackWrapper(video_filename,
                                                  realtime_wait=realtime_wait,
                                                  auto_start=False,
                                                  rgb=False,
                                                  depth=True,
                                                  ir=False)

    # Create windows for the depth image
    cv2.namedWindow("Depth", cv2.WINDOW_NORMAL)

    threshold = init_threshold

    def on_threshold_change(value):
        """
        Handler to change threshold value

        :param value: Value to set the threshold to
        """
        nonlocal threshold

        threshold = value

    # Attach Trackbar to Thresholded Depth Window
    threshold_win_name = "Thresholded Depth"
    cv2.namedWindow(threshold_win_name)
    cv2.createTrackbar("Threshold", threshold_win_name, threshold, 65536, on_threshold_change)

    # Create a mouse handler for the depth image that prints out the depth value when clicked
    def depth_click_handler(event, x, y, flags, param):
        """
        Mouse handler for Depth Image. Prints out the depth value when clicked.

        :param event: Mouse Event
        :param x: X co-ordinate
        :param y: Y co-ordinate
        :param flags: See OpenCV Docs
        :param param: Not Uses
        """
        nonlocal depth_image

        if event == cv2.EVENT_LBUTTONDOWN:
            print(f"Depth value: {depth_image[y][x]}")

    cv2.setMouseCallback("Depth", depth_click_handler)

    # Start timer
    start_time = time.time()
    playback_wrapper.start()

    try:

        first_frame = True

        # Loop through the frames
        for colour_image, depth_image, ir_image in playback_wrapper.grab_frame():

            # If all images are None, break (probably reached the end of the video)
            if colour_image is None and depth_image is None and ir_image is None:
                break

            # Threshold the depth image
            _, thresholded_depth_image = cv2.threshold(depth_image, threshold, 65536, cv2.THRESH_BINARY)

            # Create a mask for the portion of the depth image that is out of the sensor
            if first_frame:
                out_of_sensor_mask = numpy.ma.masked_where(thresholded_depth_image == 0, thresholded_depth_image)
                first_frame = False

            # Get the points where the depth image is 0 (should be object)
            points = numpy.argwhere(thresholded_depth_image == 0)

            # Select the points that are not outside of the sensor region
            bb_points = points[~out_of_sensor_mask.mask[points[:, 0], points[:, 1]]]

            # Convert the depth image to a 8-bit image, then to a colour image
            depth_image_8bit = map_uint16_to_uint8(depth_image, 0, 10000)
            depth_image_colour = cv2.cvtColor(depth_image_8bit, cv2.COLOR_GRAY2BGR)

            depth_image_thresholded_8bit = map_uint16_to_uint8(thresholded_depth_image, 0, 65535)
            depth_image_thresholded_colour = cv2.cvtColor(depth_image_thresholded_8bit, cv2.COLOR_GRAY2BGR)

            # Draw the out of sensor mask on the depth image
            depth_image_colour[out_of_sensor_mask.mask] = (0, 0, 255)
            depth_image_thresholded_colour[out_of_sensor_mask.mask] = (0, 0, 255)

            if len(bb_points) > 0:
                # Get the bounding box
                y, x, h, w = cv2.boundingRect(bb_points)

                # Draw the bounding box if it exists or is smaller than the image
                if w > 0 and h > 0 and w < depth_image.shape[1] and h < depth_image.shape[0]:
                    cv2.rectangle(depth_image_thresholded_colour, (x, y), (x + w, y + h), (0, 255, 0), 2)
                    cv2.rectangle(depth_image_colour, (x, y), (x + w, y + h), (0, 255, 0), 2)

                # Draw the bb_points in blue on the depth image
                depth_image_colour[bb_points[:, 0], bb_points[:, 1]] = (255, 0, 0)

            cv2.imshow("Depth", depth_image_colour)
            cv2.imshow(threshold_win_name, thresholded_depth_image)

            # Wait for key press
            key = cv2.waitKey(1)

            # If q or ESC is pressed, break
            if key == ord("q") or key == 27:
                break

    except KeyboardInterrupt:
        pass

    # Stop timer
    end_time = time.time()

    # Print the time taken
    print("Time taken: {}s".format(end_time - start_time))

    # Close the windows
    cv2.destroyAllWindows()

    # Stop the playback wrapper
    playback_wrapper.stop()

    return 0


if __name__ == "__main__":
    sys.exit(app())
